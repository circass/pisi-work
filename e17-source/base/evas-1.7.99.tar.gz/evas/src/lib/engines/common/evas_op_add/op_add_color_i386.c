/* add color -> dst */

#ifdef BUILD_MMX
static void
init_add_color_span_funcs_mmx(void)
{
}
#endif

#ifdef BUILD_MMX
static void
init_add_color_pt_funcs_mmx(void)
{
}
#endif

/*-----*/

/* add_rel color -> dst */

#ifdef BUILD_MMX
static void
init_add_rel_color_span_funcs_mmx(void)
{
}
#endif

#ifdef BUILD_MMX
static void
init_add_rel_color_pt_funcs_mmx(void)
{
}
#endif
