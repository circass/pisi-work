/* add mask x color -> dst */

#ifdef BUILD_C
static void
init_add_mask_color_span_funcs_c(void)
{
}
#endif

#ifdef BUILD_C
static void
init_add_mask_color_pt_funcs_c(void)
{
}
#endif

/*-----*/

/* add_rel mask x color -> dst */

#ifdef BUILD_C
static void
init_add_rel_mask_color_span_funcs_c(void)
{
}
#endif

#ifdef BUILD_C
static void
init_add_rel_mask_color_pt_funcs_c(void)
{
}
#endif
