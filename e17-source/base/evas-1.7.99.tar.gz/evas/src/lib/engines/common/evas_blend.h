#ifndef _EVAS_BLEND_H
#define _EVAS_BLEND_H


EAPI void evas_common_blend_init (void);


#endif /* _EVAS_BLEND_H */
