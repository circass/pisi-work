/* sub color -> dst */

#ifdef BUILD_C
static void
init_sub_color_span_funcs_c(void)
{
}
#endif

#ifdef BUILD_C
static void
init_sub_color_pt_funcs_c(void)
{
}
#endif

/*-----*/

/* sub_rel color -> dst */

#ifdef BUILD_C
static void
init_sub_rel_color_span_funcs_c(void)
{
}
#endif

#ifdef BUILD_C
static void
init_sub_rel_color_pt_funcs_c(void)
{
}
#endif
