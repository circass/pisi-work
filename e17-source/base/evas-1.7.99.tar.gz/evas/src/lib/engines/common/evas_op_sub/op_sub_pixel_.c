/* sub pixel --> dst */

#ifdef BUILD_C
static void
init_sub_pixel_span_funcs_c(void)
{
}
#endif

#ifdef BUILD_C
static void
init_sub_pixel_pt_funcs_c(void)
{
}
#endif

/*-----*/

/* sub_rel pixel --> dst */

#ifdef BUILD_C
static void
init_sub_rel_pixel_span_funcs_c(void)
{
}
#endif

#ifdef BUILD_C
static void
init_sub_rel_pixel_pt_funcs_c(void)
{
}
#endif
