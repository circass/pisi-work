/* add pixel --> dst */

#ifdef BUILD_MMX
static void
init_add_pixel_span_funcs_mmx(void)
{
}
#endif

#ifdef BUILD_MMX
static void
init_add_pixel_pt_funcs_mmx(void)
{
}
#endif

/*-----*/

/* add_rel pixel --> dst */

#ifdef BUILD_MMX
static void
init_add_rel_pixel_span_funcs_mmx(void)
{
}
#endif

#ifdef BUILD_MMX
static void
init_add_rel_pixel_pt_funcs_mmx(void)
{
}
#endif
