/* add pixel x color --> dst */

#ifdef BUILD_C
static void
init_add_pixel_color_span_funcs_c(void)
{
}
#endif

#ifdef BUILD_C
static void
init_add_pixel_color_pt_funcs_c(void)
{
}
#endif

/*-----*/

/* add_rel pixel x color --> dst */

#ifdef BUILD_C
static void
init_add_rel_pixel_color_span_funcs_c(void)
{
}
#endif

#ifdef BUILD_C
static void
init_add_rel_pixel_color_pt_funcs_c(void)
{
}
#endif
