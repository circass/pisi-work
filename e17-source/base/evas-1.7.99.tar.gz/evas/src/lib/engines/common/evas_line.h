#ifndef _EVAS_LINE_H
#define _EVAS_LINE_H


EAPI void          evas_common_line_init               (void);

EAPI void          evas_common_line_draw               (RGBA_Image *dst, RGBA_Draw_Context *dc, int x1, int y1, int x2, int y2);


#endif /* _EVAS_LINE_H */

