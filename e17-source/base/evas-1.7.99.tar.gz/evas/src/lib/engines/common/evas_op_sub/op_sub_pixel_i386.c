/* sub pixel --> dst */

#ifdef BUILD_MMX
static void
init_sub_pixel_span_funcs_mmx(void)
{
}
#endif

#ifdef BUILD_MMX
static void
init_sub_pixel_pt_funcs_mmx(void)
{
}
#endif

/*-----*/

/* sub_rel pixel --> dst */

#ifdef BUILD_MMX
static void
init_sub_rel_pixel_span_funcs_mmx(void)
{
}
#endif

#ifdef BUILD_MMX
static void
init_sub_rel_pixel_pt_funcs_mmx(void)
{
}
#endif
