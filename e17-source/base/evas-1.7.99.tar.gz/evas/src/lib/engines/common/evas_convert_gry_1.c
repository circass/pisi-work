#include "evas_common.h"
#include "evas_convert_gry_1.h"

#ifdef BUILD_CONVERT_1_GRY_1
void evas_common_convert_rgba_to_1bpp_gry_1_dith       (DATA32 *src, DATA8 *dst, int src_jump, int dst_jump, int w, int h, int dith_x, int dith_y, DATA8 *pal){}
#endif
