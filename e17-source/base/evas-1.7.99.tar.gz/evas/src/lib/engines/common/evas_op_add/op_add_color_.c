/* add color -> dst */

#ifdef BUILD_C
static void
init_add_color_span_funcs_c(void)
{
}
#endif

#ifdef BUILD_C
static void
init_add_color_pt_funcs_c(void)
{
}
#endif

/*-----*/

/* add_rel color -> dst */

#ifdef BUILD_C
static void
init_add_rel_color_span_funcs_c(void)
{
}
#endif

#ifdef BUILD_C
static void
init_add_rel_color_pt_funcs_c(void)
{
}
#endif
