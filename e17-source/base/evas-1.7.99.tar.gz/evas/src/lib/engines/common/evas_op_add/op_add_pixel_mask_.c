/* add pixel x mask --> dst */

#ifdef BUILD_C
/* XXX: not used
static void
init_add_pixel_mask_span_funcs_c(void)
{
}
*/
#endif

#ifdef BUILD_C
/* XXX: not used
static void
init_add_pixel_mask_pt_funcs_c(void)
{
}
*/
#endif

/*-----*/

/* add_rel pixel x mask --> dst */

#ifdef BUILD_C
static void
init_add_rel_pixel_mask_span_funcs_c(void)
{
}
#endif

#ifdef BUILD_C
static void
init_add_rel_pixel_mask_pt_funcs_c(void)
{
}
#endif
