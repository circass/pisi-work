#ifndef _EVAS_CONVERT_YUV_H
#define _EVAS_CONVERT_YUV_H

EAPI void evas_common_convert_yuv_420p_601_rgba     (DATA8 **src, DATA8 *dst, int w, int h);
EAPI void evas_common_convert_yuv_422_601_rgba      (DATA8 **src, DATA8 *dst, int w, int h);
EAPI void evas_common_convert_yuv_420_601_rgba      (DATA8 **src, DATA8 *dst, int w, int h);
EAPI void evas_common_convert_yuv_420T_601_rgba     (DATA8 **src, DATA8 *dst, int w, int h);

#endif /* _EVAS_CONVERT_YUV_H */
