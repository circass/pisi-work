/* mask mask x color -> dst */

#ifdef BUILD_MMX
static void
init_mask_mask_color_span_funcs_mmx(void)
{}
#endif

#ifdef BUILD_MMX
static void
init_mask_mask_color_pt_funcs_mmx(void)
{}
#endif
