/* sub mask x color -> dst */

#ifdef BUILD_MMX
static void
init_sub_mask_color_span_funcs_mmx(void)
{
}
#endif

#ifdef BUILD_MMX
static void
init_sub_mask_color_pt_funcs_mmx(void)
{
}
#endif

/*-----*/

/* sub_rel mask x color -> dst */

#ifdef BUILD_MMX
static void
init_sub_rel_mask_color_span_funcs_mmx(void)
{
}
#endif

#ifdef BUILD_MMX
static void
init_sub_rel_mask_color_pt_funcs_mmx(void)
{
}
#endif
