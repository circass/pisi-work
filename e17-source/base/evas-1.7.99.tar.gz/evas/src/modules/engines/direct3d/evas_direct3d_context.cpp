
#include "evas_direct3d_context.h"

D3DContext::D3DContext()
{
   color = 0xff000000;
   color_mul = 0xffffffff;
}
