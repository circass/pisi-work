
#include "evas_direct3d_object.h"

D3DObject::D3DObject()
{
   _free = false;
}

D3DObject::~D3DObject()
{
}

