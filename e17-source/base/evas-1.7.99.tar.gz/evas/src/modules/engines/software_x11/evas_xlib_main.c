#include "evas_common.h"
#include "evas_engine.h"

void
evas_software_xlib_x_init(void)
{
}
