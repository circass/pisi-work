#include "evas_common.h"
#include "evas_engine.h"

void 
evas_software_xcb_init(void) 
{

}
