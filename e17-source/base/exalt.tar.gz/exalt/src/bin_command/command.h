#ifndef  COMMAND_INC
#define  COMMAND_INC

#include <stdlib.h>
#include <string.h>
#include <Exalt_DBus.h>
#include <Exalt.h>
#include <Eina.h>

#undef __UNUSED__
#define __UNUSED__ __attribute__((unused))

void help();


#endif   /* ----- #ifndef COMMAND_INC  ----- */

