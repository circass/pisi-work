#ifndef _EPDF_FORWARD_H__
#define _EPDF_FORWARD_H__


typedef struct _Epdf_Font_Info Epdf_Font_Info;
typedef struct _Epdf_Page_Transition Epdf_Page_Transition;
typedef struct _Epdf_Page Epdf_Page;
typedef struct _Epdf_Document Epdf_Document;
typedef struct _Epdf_Index_Item Epdf_Index_Item;
typedef struct _Epdf_Postscript Epdf_Postscript;


#endif /* _EPDF_FORWARD_H__ */
