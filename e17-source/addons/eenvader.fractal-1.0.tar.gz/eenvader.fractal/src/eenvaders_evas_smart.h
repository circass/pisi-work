#ifndef EENVADERS_SMART_H
#define EENVADERS_SMART_H
#include <Evas.h>

Evas_Object *eenvaders_smart_new(Evas *e);

#endif

