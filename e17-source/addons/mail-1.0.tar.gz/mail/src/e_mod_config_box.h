#ifndef E_MOD_CONFIG_BOX_H
#define E_MOD_CONFIG_BOX_H

void _config_box (Config_Item * ci, Config_Box * cb, E_Config_Dialog * mcfd);

#endif

