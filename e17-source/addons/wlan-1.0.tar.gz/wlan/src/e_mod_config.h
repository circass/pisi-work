#ifdef E_TYPEDEFS
#else
#ifndef E_MOD_CONFIG_H
#define E_MOD_CONFIG_H

#include "e_mod_main.h"

void _configure_wlan_module(Wlan_Face *nf);

#endif
#endif
