#ifndef E_MOD_GADCON_H
# define E_MOD_GADCON_H

EINTERN void _gc_register(void);
EINTERN void _gc_unregister(void);
EINTERN const char *_gc_name(void);

#endif
