#ifndef E_MOD_CONFIGURE_H
#define E_MOD_CONFIGURE_H

EINTERN void _configure_net_module(void *data);

#endif
