#ifndef E_MOD_GADCON_H
#define E_MOD_GADCON_H

void _net_gc_register(void);
void _net_gc_unregister(void);
const char *_net_gc_name(void);

#endif
