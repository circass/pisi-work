#ifdef E_TYPEDEFS
#else
#ifndef E_MOD_CONFIG_H
#define E_MOD_CONFIG_H

#include "e_mod_main.h"

void _configure_eektool_module(Weather_Face *wf);

#endif
#endif
