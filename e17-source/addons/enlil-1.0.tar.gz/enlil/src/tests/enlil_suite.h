#ifndef ENLIL_SUITE_H_
#define ENLIL_SUITE_H_

#include <check.h>

void enlil_test_sync(TCase *tc);

#endif /* ENLIL_SUITE_H_ */
