#ifdef E_TYPEDEFS
#else
# ifndef E_MOD_CONFIG_H
#  define E_MOD_CONFIG_H
#  include "e_mod_main.h"

E_Config_Dialog *e_int_config_penguins_module(E_Container *con, const char *params);

# endif
#endif
