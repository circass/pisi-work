#include <e.h>
#include "e_mod_main.h"

/**
 * in priority order:
 *
 * @todo configure match name (to be used by actions)
 *
 * @todo configure match icccm match class and name.
 *
 * @todo configure show/hide effects:
 *        - fullscreen
 *        - centered
 *        - slide from top, bottom, left or right
 *
 * @todo match more than one, doing tabs (my idea is to do another
 *       tabbing module first, experiment with that, maybe use/reuse
 *       it here)
 */
