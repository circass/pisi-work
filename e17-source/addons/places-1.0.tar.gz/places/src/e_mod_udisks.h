#ifndef E_MOD_PLACES_UDISKS_H
#define E_MOD_PLACES_UDISKS_H

void places_udisks_init(void);
void places_udisks_shutdown(void);

#endif

