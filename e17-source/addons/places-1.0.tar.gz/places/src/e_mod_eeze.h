#ifndef E_MOD_PLACES_EEZE_H
#define E_MOD_PLACES_EEZE_H

void places_eeze_init(void);
void places_eeze_shutdown(void);

#endif

