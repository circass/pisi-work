#ifdef E_MOD_NEWS_TYPEDEFS



#else

#ifndef NEWS_CONFIG_DIALOG_LANGS_H_INCLUDED
#define NEWS_CONFIG_DIALOG_LANGS_H_INCLUDED

int  news_config_dialog_langs_show(void);
void news_config_dialog_langs_hide(void);

#endif
#endif
