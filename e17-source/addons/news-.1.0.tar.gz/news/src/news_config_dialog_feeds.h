#ifdef E_MOD_NEWS_TYPEDEFS



#else

#ifndef NEWS_CONFIG_DIALOG_FEEDS_H_INCLUDED
#define NEWS_CONFIG_DIALOG_FEEDS_H_INCLUDED

int  news_config_dialog_feeds_show(void);
void news_config_dialog_feeds_hide(void);

void news_config_dialog_feeds_refresh_feeds(void);
void news_config_dialog_feeds_refresh_categories(void);

#endif
#endif
