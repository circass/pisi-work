#ifdef E_MOD_NEWS_TYPEDEFS



#else

#ifndef NEWS_CONFIG_DIALOG_CATEGORY_H_INCLUDED
#define NEWS_CONFIG_DIALOG_CATEGORY_H_INCLUDED

int  news_config_dialog_category_show(News_Feed_Category *fcat);
void news_config_dialog_category_hide(News_Feed_Category *fcat);

#endif
#endif
