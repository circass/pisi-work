#ifndef _ELFE_WINLIST_H_
#define _ELFE_WINLIST_H_

int elfe_winlist_init(void);
int elfe_winlist_shutdown(void);

Evas_Object *e_winilist_add(Evas_Object *parent);

#endif /* _ELFE_WINLIST_H_ */
