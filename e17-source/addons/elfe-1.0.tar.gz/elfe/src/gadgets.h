#ifndef _GADGET_LIST_H_
#define _GADGET_LIST_H_

Evas_Object *elfe_gadget_list_add(Evas_Object *obj);

#endif /* _GADGET_LIST_H_ */
