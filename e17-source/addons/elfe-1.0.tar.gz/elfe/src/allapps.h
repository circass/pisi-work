#ifndef _ALLAPPS_H_
#define _ALLAPPS_H_

#include <Elementary.h>

Evas_Object *elfe_allapps_add(Evas_Object *parent);

#endif /* _ALLAPPS_H_ */
