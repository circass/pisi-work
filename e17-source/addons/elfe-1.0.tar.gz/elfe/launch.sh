#!/bin/sh
x-ui.sh --profile=illume --screen=480x800