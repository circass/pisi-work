#ifndef E_INT_CONFIG_IIIRK_H
#define E_INT_CONFIG_IIIRK_H

E_Config_Dialog *e_int_config_apps_iiirk(E_Container *con);
E_Config_Dialog *e_int_config_apps_iiirk_other(E_Container *con, const char *path);

#endif
