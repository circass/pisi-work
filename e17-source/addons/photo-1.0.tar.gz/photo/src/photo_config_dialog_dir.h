#ifdef E_MOD_PHOTO_TYPEDEFS



#else

#ifndef PHOTO_CONFIG_DIALOG_DIR_H_INCLUDED
#define PHOTO_CONFIG_DIALOG_DIR_H_INCLUDED

int  photo_config_dialog_dir_show(Picture_Local_Dir *dir);
void photo_config_dialog_dir_hide(Picture_Local_Dir *dir);

#endif
#endif
