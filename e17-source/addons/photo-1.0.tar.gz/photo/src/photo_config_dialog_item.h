#ifdef E_MOD_PHOTO_TYPEDEFS



#else

#ifndef PHOTO_CONFIG_DIALOG_ITEM_H_INCLUDED
#define PHOTO_CONFIG_DIALOG_ITEM_H_INCLUDED

int  photo_config_dialog_item_show(Photo_Item *pi);
void photo_config_dialog_item_hide(Photo_Item *pi);

#endif
#endif
