#ifdef E_MOD_PHOTO_TYPEDEFS



#else

#ifndef PHOTO_MENU_H_INCLUDED
#define PHOTO_MENU_H_INCLUDED

int  photo_menu_show(Photo_Item *pi);
void photo_menu_hide(Photo_Item *pi);

#endif
#endif
