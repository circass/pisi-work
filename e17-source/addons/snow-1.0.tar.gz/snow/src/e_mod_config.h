#ifdef E_TYPEDEFS
#else
#ifndef E_MOD_CONFIG_H
#define E_MOD_CONFIG_H

E_Config_Dialog *e_int_config_snow_module(E_Container *con, const char *params);

#endif
#endif
